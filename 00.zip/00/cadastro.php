<pre>
<?php
    // dados do banco de dados
    $host       = 'localhost';
    $dbName     = 'gorgonzolaFinancas';
    $dbUser     = 'root';
    $dbPassword = '';

    // conectando ao banco de dados
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPassword
    );

    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $nivel = $_POST['nivel'];
    $data_nascimento = $_POST['data_nascimento'];

    $query_sql = "INSERT INTO `usuarios` 
                (`nome`, `email`, `senha`, `nivel`, `data_nascimento`) 
                VALUES 
                (?, ?, ?, ?, ?);
    ";

    $stmt = $pdo->prepare($query_sql);
    $stmt->execute([$nome, $email, $senha, $nivel, $data_nascimento]);

    header("location: index.php");