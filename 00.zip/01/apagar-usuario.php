<?php
session_start();

if (!isset($_SESSION['logado']) || $_SESSION['nivel'] != 'admin') {
    header("location: index.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $host       = 'localhost';
    $dbName     = 'gorgonzolaFinancas';
    $dbUser     = 'root';
    $dbPassword = '';

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
        $dbUser,
        $dbPassword
    );

    $sql = "DELETE FROM usuarios WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
}

header("location: dashboard.php");