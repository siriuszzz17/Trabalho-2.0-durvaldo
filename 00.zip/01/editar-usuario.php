<?php
session_start();

if (!isset($_SESSION['logado']) || $_SESSION['nivel'] != 'admin') {
    header("location: index.php");
    exit;
}

$host       = 'localhost';
$dbName     = 'gorgonzolaFinancas';
$dbUser     = 'root';
$dbPassword = '';

$pdo = new PDO(
    "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
    $dbUser,
    $dbPassword
);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id              = $_POST['id'];
    $nome            = $_POST['nome'];
    $email           = $_POST['email'];
    $senha           = $_POST['senha'];
    $nivel           = $_POST['nivel'];
    $data_nascimento = $_POST['data_nascimento'];

    $sql = "UPDATE usuarios 
            SET nome = ?, email = ?, senha = ?, nivel = ?, data_nascimento = ? 
            WHERE id = ?";
            
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nome, $email, $senha, $nivel, $data_nascimento, $id]);

    header("location: dashboard.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar usuario</title>
</head>
<body>
    <h1>Editar Usuário</h1>

    <form action="editar-usuario.php" method="POST">
        <input type="hidden" name="id" value="<?= $usuario['id'] ?>">

        <div>
            <label for="nome">Nome</label>
            <input type="text" name="nome" id="nome" value="<?= $usuario['nome'] ?>">
        </div>
        <div>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?= $usuario['email'] ?>">
        </div>
        <div>
            <label for="senha">Senha</label>
            <input type="text" name="senha" id="senha" value="<?= $usuario['senha'] ?>">
        </div>
        <div>
            <label for="data_nascimento">Data de nascimento</label>
            <input type="date" name="data_nascimento" id="data_nascimento" value="<?= $usuario['data_nascimento'] ?>">
        </div>
        <div>
            <label for="nivel">Nivel</label>
            <select name="nivel" id="nivel">
                <option value="admin" <?= $usuario['nivel'] == 'admin' ? 'selected' : '' ?>>Administrador</option>
                <option value="cliente" <?= $usuario['nivel'] == 'cliente' ? 'selected' : '' ?>>Cliente</option>
            </select>
        </div>
        
        <button type="submit">Salvar</button>
        <a href="dashboard.php"><button type="button">Cancelar</button></a>
    </form>
</body>
</html>